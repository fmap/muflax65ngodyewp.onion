#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright muflax <mail@muflax.com>, 2010
# License: GNU GPL 3 <http://www.gnu.org/copyleft/gpl.html>

import re, sys, unicodedata

def iskanji(char):
    return char.isalpha() and unicodedata.name(char).find('CJK UNIFIED IDEOGRAPH') >= 0

def build_lookup_dic():
    good_parts = re.compile("[\u3040-\u30ff]+.*$")
    dic = {}
    with open("kanjidic", encoding="eucjp") as f:
        for line in f:
            kanji = line[0]
            match = good_parts.search(line)
            if match:
                entry = match.group()
                entry = entry.replace(" {", "<br/>")
                entry = entry.replace("}", "")
                dic[kanji] = entry
    return dic

def main():
    dic = build_lookup_dic()

    failed = []
    for char in "".join(sys.argv[1:]):
        if  iskanji(char):
            try:
                print(char, "\t", dic[char])
            except KeyError:
                failed.append(char)
    if failed:
        print("failed: ", " ".join(failed))
    

if __name__ == "__main__":
    main()

