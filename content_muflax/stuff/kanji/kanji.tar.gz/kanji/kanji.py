#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright muflax <muflax@gmail.com>, 2009
# License: GNU GPL 3 <http://www.gnu.org/copyleft/gpl.html>

import unicodedata, sys

def iskanji(char):
    return char.isalpha() and unicodedata.name(char).find('CJK UNIFIED IDEOGRAPH') >= 0

def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print("usage: %s kanji-file files-to-be-compared-against" % sys.argv[0])
        sys.exit(1)

    kanji = set([])
    missing = set([])
    for line in open(sys.argv[1]):
        for char in line:
            if iskanji(char):
                kanji.add(char)

    for file in sys.argv[2:]:
        file = open(file)
        for line in file:
            for char in line:
                if iskanji(char) and char not in kanji:
                    missing.add(char)

    kl = list(kanji)
    kl.sort()
    ml = list(missing)
    ml.sort()
    print("%d 漢字 already included:" % len(kl))
    print("".join(kl))
    if ml:
        print("%d 漢字 missing:" % len(ml))
        print("".join(ml))

if __name__ == "__main__":
    main()

